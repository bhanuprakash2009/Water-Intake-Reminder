"""ANSI menu-driven CLI with fixed-width paginated tables."""
import os
from datetime import date, datetime
from .validators import (validated_input, validate_id, validate_date, validate_time,
                         validate_amount, validate_target, validate_text)
from .importer import import_csv
from .exporters import export_markdown, export_csv, export_audit, export_chart


class TerminalUI:
    RESET, CYAN, GREEN, YELLOW, RED, BOLD = "\033[0m", "\033[96m", "\033[92m", "\033[93m", "\033[91m", "\033[1m"

    def __init__(self, service, page_size=10):
        self.service, self.page_size = service, page_size

    def header(self):
        os.system("cls" if os.name == "nt" else "clear")
        print(f"{self.CYAN}{self.BOLD}╔══════════════════════════════════════════════╗")
        print("║           WATER INTAKE REMINDER LOG          ║")
        print(f"╚══════════════════════════════════════════════╝{self.RESET}")

    def table(self, records):
        if not records:
            print("No intake entries found."); return
        widths = (10, 10, 7, 10, 14, 22)
        headers = ("ENTRY ID", "DATE", "TIME", "AMOUNT", "BEVERAGE", "NOTES")
        print(" | ".join(h.ljust(w) for h, w in zip(headers, widths)))
        print("-+-".join("-" * w for w in widths))
        for start in range(0, len(records), self.page_size):
            for r in records[start:start+self.page_size]:
                vals = (r.entry_id, r.entry_date, r.entry_time, str(r.amount_ml),
                        r.beverage, r.notes)
                print(" | ".join(v[:w].ljust(w) for v, w in zip(vals, widths)))
            if start + self.page_size < len(records):
                input(f"\n-- Page {start // self.page_size + 1}; Enter for next --")

    def summary(self):
        s = self.service.summary()
        print("\nEXECUTIVE WATER INTAKE SUMMARY")
        for key in ("entry_count", "days_tracked", "total_intake_ml", "average_daily_ml",
                    "daily_target_ml", "target_achieved_days", "target_missed_days",
                    "today_total_ml", "today_status"):
            print(f"{key.replace('_', ' ').title():24}: {s[key]}")
        print("\nDaily totals:")
        for day, amount in s["daily_totals"].items():
            flag = "✓ TARGET MET" if amount >= s["daily_target_ml"] else "! BELOW TARGET"
            print(f"  {day}: {amount:5} ml / {s['daily_target_ml']} ml  {flag}")
        print("\nBeverage totals:")
        for name, amount in s["beverage_totals"].items():
            print(f"  {name:20} {amount:6} ml")
        if s["today_status"] == "below_target":
            print(f"{self.YELLOW}Reminder: today's recorded intake is below your target.{self.RESET}")

    def add(self):
        record = self.service.add_entry(
            entry_id=validated_input("Entry ID: ", validate_id),
            entry_date=validated_input("Date YYYY-MM-DD: ", validate_date),
            entry_time=validated_input("Time HH:MM: ", validate_time),
            amount_ml=validated_input("Amount in ml: ", validate_amount),
            beverage=validated_input("Beverage: ", lambda x: validate_text(x, "Beverage")),
            notes=input("Notes (optional): ").strip())
        print(f"{self.GREEN}Recorded {record.amount_ml} ml successfully.{self.RESET}")

    def run(self):
        while True:
            self.header()
            print(f"Daily target: {self.service.daily_target_ml} ml")
            print("1. Record intake       2. View entries")
            print("3. Search/filter       4. Executive summary")
            print("5. Change daily target 6. Import CSV")
            print("7. Export reports      0. Exit")
            choice = input("\nSelect: ").strip()
            try:
                if choice == "1": self.add()
                elif choice == "2": self.table(self.service.list_entries())
                elif choice == "3":
                    self.table(self.service.search_entries(input("Keyword: ").strip(),
                                                            input("Beverage filter: ").strip()))
                elif choice == "4": self.summary()
                elif choice == "5":
                    target = validated_input("New target (ml): ", validate_target)
                    self.service.set_daily_target(target)
                    print(f"Target updated to {target} ml.")
                elif choice == "6":
                    result = import_csv(input("CSV path: ").strip(), self.service)
                    print(f"Imported {result['imported']}; rejected {len(result['errors'])}.")
                    for error in result["errors"]: print(" ", error)
                elif choice == "7":
                    export_markdown(self.service, "reports/water_summary.md")
                    export_csv(self.service, "reports/water_summary.csv")
                    export_audit(self.service, "reports/audit_export.txt")
                    try:
                        export_chart(self.service, "reports/water_intake_trend.png")
                        print("Markdown, CSV, audit and chart exported to reports/.")
                    except ImportError:
                        print("Reports exported; install Matplotlib to generate the chart.")
                elif choice == "0":
                    self.service.storage.audit("Application closed.")
                    print("Goodbye."); return
                else: print(f"{self.YELLOW}Choose a displayed menu option.{self.RESET}")
            except (OSError, ValueError) as exc:
                print(f"{self.RED}Operation failed: {exc}{self.RESET}")
            input("\nPress Enter to continue...")
