"""Domain models for water intake tracking."""
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any


class IntakeStatus(str, Enum):
    BELOW_TARGET = "below_target"
    ON_TARGET = "on_target"
    ABOVE_TARGET = "above_target"


@dataclass(frozen=True, slots=True)
class IntakeRecord:
    """One water-intake entry, measured in millilitres."""
    entry_id: str
    entry_date: str
    entry_time: str
    amount_ml: int
    beverage: str = "Water"
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "IntakeRecord":
        return cls(str(data["entry_id"]), str(data["entry_date"]),
                   str(data.get("entry_time", "12:00")),
                   int(data["amount_ml"]), str(data.get("beverage", "Water")),
                   str(data.get("notes", "")))
