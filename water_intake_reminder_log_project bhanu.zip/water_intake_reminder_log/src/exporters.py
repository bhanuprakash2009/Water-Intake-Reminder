"""Export Markdown, CSV, audit log and Matplotlib trend charts."""
import csv
from pathlib import Path


def export_markdown(service, path):
    s = service.summary()
    lines = ["# Water Intake Summary", "", f"- Entries: {s['entry_count']}",
        f"- Days tracked: {s['days_tracked']}", f"- Total intake: {s['total_intake_ml']} ml",
        f"- Average daily intake: {s['average_daily_ml']} ml",
        f"- Daily target: {s['daily_target_ml']} ml",
        f"- Target achieved days: {s['target_achieved_days']}", "",
        "## Daily totals", "", "| Date | Intake (ml) | Target |", "|---|---:|---:|"]
    lines += [f"| {day} | {total} | {s['daily_target_ml']} |"
              for day, total in s["daily_totals"].items()]
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    service.storage.audit(f"Exported Markdown report: {target}")
    return target


def export_csv(service, path):
    s = service.summary()
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(target.name + ".tmp")
    with temp.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle); writer.writerow(["date", "intake_ml", "target_ml", "status"])
        for day, total in s["daily_totals"].items():
            status = "achieved" if total >= s["daily_target_ml"] else "below_target"
            writer.writerow([day, total, s["daily_target_ml"], status])
    temp.replace(target)
    service.storage.audit(f"Exported CSV report: {target}")
    return target


def export_audit(service, path):
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(service.storage.audit_path.read_text(encoding="utf-8")
                      if service.storage.audit_path.exists() else "", encoding="utf-8")
    return target


def export_chart(service, path):
    """Create a daily intake trend PNG using Matplotlib."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    summary = service.summary()
    days = list(summary["daily_totals"])
    values = [summary["daily_totals"][day] for day in days]
    fig, ax = plt.subplots(figsize=(10, 4.5))
    if days:
        ax.plot(days, values, marker="o", label="Water intake")
        ax.axhline(summary["daily_target_ml"], linestyle="--", label="Daily target")
        ax.tick_params(axis="x", rotation=45)
        ax.legend()
    ax.set_title("Daily Water Intake Trend")
    ax.set_ylabel("Millilitres (ml)")
    ax.set_xlabel("Date")
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(target, dpi=160)
    plt.close(fig)
    service.storage.audit(f"Exported intake chart: {target}")
    return target
