"""Bulk CSV import with row-level validation and audit logging."""
import csv
from pathlib import Path
from .validators import ValidationError


def import_csv(path, service):
    imported, errors = 0, []
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"entry_id", "entry_date", "entry_time", "amount_ml"}
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            raise ValueError(f"CSV requires columns: {', '.join(sorted(required))}")
        for line, row in enumerate(reader, start=2):
            try:
                service.add_entry(entry_id=row.get("entry_id", ""),
                    entry_date=row.get("entry_date", ""), entry_time=row.get("entry_time", ""),
                    amount_ml=row.get("amount_ml", ""), beverage=row.get("beverage", "Water"),
                    notes=row.get("notes", ""))
                imported += 1
            except (ValidationError, ValueError, TypeError) as exc:
                message = f"Row {line}: {exc}"
                errors.append(message)
                service.storage.audit(f"CSV import rejected: {message}")
    service.storage.audit(f"CSV import completed: {imported} imported, {len(errors)} rejected.")
    return {"imported": imported, "errors": errors}
