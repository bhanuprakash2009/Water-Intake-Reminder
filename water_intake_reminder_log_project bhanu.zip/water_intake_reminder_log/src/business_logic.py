"""Water-intake recording, daily target comparison and analytics."""
from collections import defaultdict
from datetime import date
from .models import IntakeRecord, IntakeStatus
from .storage import Storage
from .validators import (ValidationError, validate_id, validate_date, validate_time,
                         validate_amount, validate_text, validate_target)


class WaterIntakeService:
    """Shared use cases for CLI and Streamlit interfaces."""
    def __init__(self, storage: Storage, daily_target_ml: int = 2000):
        self.storage = storage
        self.daily_target_ml = validate_target(daily_target_ml)

    def set_daily_target(self, target_ml: object) -> int:
        self.daily_target_ml = validate_target(target_ml)
        self.storage.audit(f"Daily target changed to {self.daily_target_ml} ml.")
        return self.daily_target_ml

    def add_entry(self, *, entry_id: str, entry_date: str, entry_time: str,
                  amount_ml: object, beverage: str = "Water", notes: str = "") -> IntakeRecord:
        records = self.storage.load_records()
        clean_id = validate_id(entry_id)
        if any(r.entry_id.casefold() == clean_id.casefold() for r in records):
            raise ValidationError(f"Entry ID '{clean_id}' already exists.")
        record = IntakeRecord(clean_id, validate_date(entry_date), validate_time(entry_time),
            validate_amount(amount_ml), validate_text(beverage, "Beverage"),
            validate_text(notes, "Notes", optional=True))
        records.append(record)
        self.storage.save_records(records)
        self.storage.audit(f"Recorded {record.amount_ml} ml ({record.beverage}) on {record.entry_date}.")
        return record

    def list_entries(self):
        return self.storage.load_records()

    def search_entries(self, keyword="", beverage=""):
        return self.storage.search(keyword, beverage)

    def daily_total(self, day: str | None = None) -> int:
        selected = day or date.today().isoformat()
        return sum(r.amount_ml for r in self.list_entries() if r.entry_date == selected)

    def daily_status(self, day: str | None = None) -> IntakeStatus:
        total = self.daily_total(day)
        if total < self.daily_target_ml:
            return IntakeStatus.BELOW_TARGET
        if total == self.daily_target_ml:
            return IntakeStatus.ON_TARGET
        return IntakeStatus.ABOVE_TARGET

    def summary(self):
        records = self.list_entries()
        daily = defaultdict(int)
        beverage_totals = defaultdict(int)
        for record in records:
            daily[record.entry_date] += record.amount_ml
            beverage_totals[record.beverage] += record.amount_ml
        totals = list(daily.values())
        average = round(sum(totals) / len(totals), 1) if totals else 0.0
        achieved = sum(value >= self.daily_target_ml for value in totals)
        return {
            "entry_count": len(records), "days_tracked": len(daily),
            "total_intake_ml": sum(r.amount_ml for r in records),
            "average_daily_ml": average, "daily_target_ml": self.daily_target_ml,
            "target_achieved_days": achieved,
            "target_missed_days": len(daily) - achieved,
            "daily_totals": dict(sorted(daily.items())),
            "beverage_totals": dict(sorted(beverage_totals.items(), key=lambda x: -x[1])),
            "today_total_ml": self.daily_total(),
            "today_status": self.daily_status().value,
        }
