"""Defensive input validation and retrying prompt helpers."""
import re
from datetime import date, time
from typing import Callable, TypeVar

T = TypeVar("T")
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{1,39}$")
TEXT_RE = re.compile(r"^[\w .,&'()/+-]{1,80}$", re.UNICODE)


class ValidationError(ValueError):
    """Raised when a water-log field is invalid."""


def validate_id(value: str) -> str:
    value = value.strip()
    if not ID_RE.fullmatch(value):
        raise ValidationError("Entry ID must be 2–40 letters, digits, _ or -.")
    return value


def validate_date(value: str) -> str:
    try:
        return date.fromisoformat(value.strip()).isoformat()
    except (AttributeError, ValueError):
        raise ValidationError("Date must use YYYY-MM-DD format.") from None


def validate_time(value: str) -> str:
    try:
        return time.fromisoformat(value.strip()).strftime("%H:%M")
    except (AttributeError, ValueError):
        raise ValidationError("Time must use HH:MM format.") from None


def validate_amount(value: object) -> int:
    try:
        amount = int(str(value).strip())
    except (TypeError, ValueError):
        raise ValidationError("Water amount must be a whole number of millilitres.") from None
    if not 1 <= amount <= 5000:
        raise ValidationError("Each entry must be between 1 and 5000 ml.")
    return amount


def validate_target(value: object) -> int:
    try:
        target = int(str(value).strip())
    except (TypeError, ValueError):
        raise ValidationError("Daily target must be a whole number of millilitres.") from None
    if not 250 <= target <= 10000:
        raise ValidationError("Daily target must be between 250 and 10000 ml.")
    return target


def validate_text(value: str, label: str, optional: bool = False) -> str:
    value = value.strip()
    if optional and not value:
        return ""
    if not value or not TEXT_RE.fullmatch(value):
        raise ValidationError(f"{label} is required and must be at most 80 valid characters.")
    return value


def validated_input(prompt: str, parser: Callable[[str], T], input_fn=input) -> T:
    while True:
        raw = input_fn(prompt)
        try:
            return parser(raw)
        except (ValidationError, ValueError) as exc:
            print(f"  ! {exc} Please try again.")
