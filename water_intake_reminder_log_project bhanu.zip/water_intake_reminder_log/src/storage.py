"""Thread/process-safe JSON, CSV and indexed SQLite persistence."""
import csv
import io
import json
import os
import sqlite3
import tempfile
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator
from .models import IntakeRecord

try:
    import fcntl
except ImportError:  # Windows
    fcntl = None
try:
    import msvcrt
except ImportError:  # Unix
    msvcrt = None


class Storage:
    FIELDS = ["entry_id", "entry_date", "entry_time", "amount_ml", "beverage", "notes"]

    def __init__(self, data_dir="data", audit_path="reports/audit_log.txt"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "intake.json"
        self.csv_path = self.data_dir / "intake.csv"
        self.db_path = self.data_dir / "intake.db"
        self.audit_path = Path(audit_path)
        self.audit_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path = self.data_dir / ".intake.lock"
        self._lock = threading.RLock()
        self._init_db()
        self.load_records()

    @contextmanager
    def _locked(self) -> Iterator[None]:
        with self._lock:
            with self.lock_path.open("a+b") as handle:
                try:
                    if fcntl:
                        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                    elif msvcrt:
                        handle.seek(0)
                        msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
                    yield
                finally:
                    try:
                        if fcntl:
                            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                        elif msvcrt:
                            handle.seek(0)
                            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                    except OSError:
                        pass

    @staticmethod
    def _atomic_write(path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS intake (
                entry_id TEXT PRIMARY KEY, entry_date TEXT NOT NULL, entry_time TEXT NOT NULL,
                amount_ml INTEGER NOT NULL, beverage TEXT NOT NULL, notes TEXT NOT NULL)""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_intake_date ON intake(entry_date)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_intake_beverage ON intake(beverage)")
            conn.commit()

    def _sync_db(self, records) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM intake")
            conn.executemany("INSERT INTO intake VALUES (?, ?, ?, ?, ?, ?)",
                [(r.entry_id, r.entry_date, r.entry_time, r.amount_ml, r.beverage, r.notes)
                 for r in records])
            conn.commit()

    def _write_json(self, records) -> None:
        self._atomic_write(self.json_path,
            json.dumps([r.to_dict() for r in records], indent=2, ensure_ascii=False) + "\n")

    def _write_csv(self, records) -> None:
        buf = io.StringIO(newline="")
        writer = csv.DictWriter(buf, fieldnames=self.FIELDS)
        writer.writeheader()
        for record in records:
            writer.writerow({key: getattr(record, key) for key in self.FIELDS})
        self._atomic_write(self.csv_path, buf.getvalue())

    def audit(self, message: str) -> None:
        stamp = datetime.now().astimezone().isoformat(timespec="seconds")
        with self._locked():
            with self.audit_path.open("a", encoding="utf-8") as handle:
                handle.write(f"[{stamp}] {message}\n")

    def load_records(self):
        recovered = None
        with self._locked():
            if not self.json_path.exists():
                records = []
                self._write_json(records)
                recovered = "Missing JSON register initialized."
            else:
                try:
                    raw = json.loads(self.json_path.read_text(encoding="utf-8"))
                    if not isinstance(raw, list):
                        raise json.JSONDecodeError("Expected a list", str(self.json_path), 0)
                    records = [IntakeRecord.from_dict(row) for row in raw]
                except (json.JSONDecodeError, FileNotFoundError, KeyError, TypeError, ValueError) as exc:
                    backup = self.json_path.with_name(
                        f"intake_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.bak")
                    if self.json_path.exists():
                        os.replace(self.json_path, backup)
                    records = []
                    self._write_json(records)
                    recovered = f"Corrupt JSON archived as {backup.name}: {exc}"
            self._sync_db(records)
            if not self.csv_path.exists():
                self._write_csv(records)
        if recovered:
            self.audit(recovered)
        return records

    def save_records(self, records) -> None:
        with self._locked():
            self._write_json(records)
            self._write_csv(records)
            self._sync_db(records)
        self.audit(f"Saved intake register ({len(records)} records).")

    def search(self, keyword="", beverage=""):
        sql = """SELECT entry_id, entry_date, entry_time, amount_ml, beverage, notes
                 FROM intake WHERE 1=1"""
        args = []
        if keyword.strip():
            term = f"%{keyword.strip()}%"
            sql += " AND (entry_id LIKE ? OR notes LIKE ?)"
            args.extend([term, term])
        if beverage.strip():
            sql += " AND beverage LIKE ?"
            args.append(f"%{beverage.strip()}%")
        sql += " ORDER BY entry_date DESC, entry_time DESC"
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(sql, args).fetchall()
        return [IntakeRecord(*row) for row in rows]
