# Water Intake Reminder Log — Project #31

Python mini-project for recording water intake and comparing daily totals with a user-set
daily target. The application is local-first and includes CLI, Streamlit GUI, persistence,
search, analytics, imports, exports and charts.

## Features
- Menu-driven ANSI terminal UI with paginated tables.
- Native Streamlit dashboard (no raw HTML/CSS/unsafe HTML).
- Shared modular Python backend.
- User-set daily water target; daily totals and below/on/above target status.
- Defensive validation for IDs, dates, times, intake amounts and target values.
- JSON and CSV persistence with atomic writes and SQLite indexes.
- Thread/process locking and timestamped audit log.
- Corrupt JSON timestamped backup and clean-register recovery.
- Keyword/beverage search and bulk CSV import with row-by-row error logging.
- Executive summary, target warnings, Markdown/CSV/audit exports.
- Matplotlib daily trend chart.
- 40 seeded sample entries, unit tests, CI workflow and API reference.

## Requirements
Python 3.10+. Core backend/CLI use the standard library. Streamlit and Matplotlib
are used only for the graphical interface and chart generation.

## Run CLI
```bash
python main.py
```

## Run Streamlit UI
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app_streamlit.py
```

## Tests
```bash
python -m unittest discover -s tests -v
```

## Seed data and CSV schema
The project includes 40 entries in `data/intake.json` and `data/intake.csv`.
CSV columns: `entry_id,entry_date,entry_time,amount_ml,beverage,notes`.
Date format: YYYY-MM-DD; time format: HH:MM; each intake entry: 1–5000 ml;
daily target: 250–10000 ml.

## Project structure
`src/` shared backend and CLI UI; `data/` local JSON/CSV/SQLite; `reports/` exports;
`tests/` automated tests; `docs/API_REFERENCE.md`; `main.py`; `app_streamlit.py`.
