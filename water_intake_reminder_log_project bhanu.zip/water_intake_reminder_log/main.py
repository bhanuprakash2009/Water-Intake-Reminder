"""Launch the Water Intake Reminder Log terminal application."""
from src.storage import Storage
from src.business_logic import WaterIntakeService
from src.ui import TerminalUI


def main():
    storage = Storage()
    service = WaterIntakeService(storage)
    storage.audit("Application started (CLI).")
    TerminalUI(service).run()


if __name__ == "__main__":
    main()
