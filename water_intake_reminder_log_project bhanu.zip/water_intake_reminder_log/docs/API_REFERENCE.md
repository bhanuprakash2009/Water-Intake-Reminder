# API Reference — Water Intake Reminder Log

## Models (`src.models`)
- `IntakeRecord`: immutable record with entry ID, date, time, amount in ml, beverage and notes.
- `IntakeStatus`: `below_target`, `on_target`, `above_target`.

## Validation (`src.validators`)
- `ValidationError`: domain validation exception.
- `validate_id`, `validate_date`, `validate_time`, `validate_amount`,
  `validate_target`, `validate_text`: normalize and validate user data.
- `validated_input`: retries prompts until valid input is received.
- Intake amount range: 1–5000 ml per entry. Daily target range: 250–10000 ml.

## Persistence (`src.storage.Storage`)
`Storage(data_dir="data", audit_path="reports/audit_log.txt")` manages JSON/CSV and
SQLite. It creates indexes on date and beverage, uses `threading.RLock` plus OS advisory
locking, and atomically replaces JSON/CSV through same-directory temporary files.
Methods: `load_records`, `save_records`, `search`, `audit`.

## Business logic (`src.business_logic.WaterIntakeService`)
- `set_daily_target(target_ml)`: validate and set the daily target.
- `add_entry(...)`: validate and persist a water-intake entry.
- `daily_total(day=None)`: sum all recorded intake for a date (today by default).
- `daily_status(day=None)`: compare daily total with configured target.
- `summary()`: totals, average daily intake, achieved/missed days, beverage and daily trends.

## Import/export
- `src.importer.import_csv(path, service)`: row-by-row CSV import and error logging.
- `src.exporters`: Markdown, CSV, audit and Matplotlib PNG chart exporters.

## Interfaces
`main.py` launches the ANSI paginated terminal UI.
`app_streamlit.py` provides a native Streamlit dashboard and forms.
Both interfaces use the same service and storage modules.
