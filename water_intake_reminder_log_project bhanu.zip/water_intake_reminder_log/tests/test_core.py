"""Unit tests for validation, intake calculations, recovery and indexing."""
import csv
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from src.storage import Storage
from src.business_logic import WaterIntakeService
from src.validators import ValidationError, validate_amount, validate_target
from src.importer import import_csv


class WaterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.storage = Storage(base / "data", base / "reports" / "audit.txt")
        self.service = WaterIntakeService(self.storage, 2000)

    def tearDown(self):
        self.tmp.cleanup()

    def add(self, eid="W-001", **kwargs):
        values = dict(entry_date="2026-11-20", entry_time="09:30", amount_ml=500,
                      beverage="Water", notes="")
        values.update(kwargs)
        return self.service.add_entry(entry_id=eid, **values)

    def test_validation_boundaries(self):
        self.assertEqual(validate_amount("1"), 1)
        self.assertEqual(validate_amount("5000"), 5000)
        self.assertEqual(validate_target("250"), 250)
        for value in ("", "abc", "0", "-1", "5001"):
            with self.assertRaises(ValidationError):
                validate_amount(value)

    def test_daily_total_and_target_status(self):
        self.add()
        self.add(eid="W-002", amount_ml=1500, entry_time="12:00")
        self.assertEqual(self.service.daily_total("2026-11-20"), 2000)
        self.assertEqual(self.service.daily_status("2026-11-20").value, "on_target")

    def test_below_and_above_target(self):
        self.add()
        self.assertEqual(self.service.daily_status("2026-11-20").value, "below_target")
        self.add(eid="W-002", amount_ml=2000, entry_time="14:00")
        self.assertEqual(self.service.daily_status("2026-11-20").value, "above_target")

    def test_duplicate_id_and_search(self):
        self.add()
        with self.assertRaises(ValidationError):
            self.add()
        self.assertEqual(len(self.service.search_entries("W-001", "Water")), 1)

    def test_corrupt_json_recovery(self):
        self.storage.json_path.write_text("{bad", encoding="utf-8")
        self.assertEqual(self.storage.load_records(), [])
        self.assertTrue(list(self.storage.data_dir.glob("intake_*.bak")))
        self.assertEqual(json.loads(self.storage.json_path.read_text()), [])

    def test_sqlite_indexes(self):
        with sqlite3.connect(self.storage.db_path) as conn:
            names = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='index'")}
        self.assertTrue({"idx_intake_date", "idx_intake_beverage"} <= names)

    def test_csv_import_row_errors(self):
        path = Path(self.tmp.name) / "input.csv"
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["entry_id", "entry_date", "entry_time", "amount_ml"])
            writer.writeheader()
            writer.writerow(dict(entry_id="IMP-1", entry_date="2026-11-20", entry_time="10:00", amount_ml="300"))
            writer.writerow(dict(entry_id="IMP-2", entry_date="bad", entry_time="10:00", amount_ml="x"))
        result = import_csv(path, self.service)
        self.assertEqual(result["imported"], 1)
        self.assertEqual(len(result["errors"]), 1)


if __name__ == "__main__":
    unittest.main()
