"""Native Streamlit GUI sharing the CLI backend."""
from pathlib import Path
import streamlit as st
from src.storage import Storage
from src.business_logic import WaterIntakeService
from src.importer import import_csv
from src.exporters import export_markdown, export_csv, export_chart

st.set_page_config(page_title="Water Intake Reminder Log", page_icon="💧", layout="wide")
st.title("💧 Water Intake Reminder Log")
st.caption("Record hydration • compare with your daily target • review trends")

@st.cache_resource
def get_service():
    return WaterIntakeService(Storage())

service = get_service()
page = st.sidebar.radio("Navigate", ["Dashboard", "Intake register", "Record intake", "Import CSV", "Exports"])

if page == "Dashboard":
    s = service.summary()
    a, b, c, d = st.columns(4)
    a.metric("Today's intake", f"{s['today_total_ml']:,} ml")
    b.metric("Daily target", f"{s['daily_target_ml']:,} ml")
    c.metric("Total entries", s["entry_count"])
    d.metric("Average daily intake", f"{s['average_daily_ml']:,.0f} ml")
    progress = min(s["today_total_ml"] / s["daily_target_ml"], 1.0)
    st.progress(progress, text=f"Today's target progress: {progress:.0%}")
    if s["today_status"] == "below_target":
        st.warning("Today's recorded intake is below your target.")
    elif s["today_status"] == "on_target":
        st.success("Daily target reached.")
    else:
        st.success("Daily target exceeded.")
    target = st.number_input("Set daily target (ml)", min_value=250, max_value=10000,
                             value=service.daily_target_ml, step=250)
    if st.button("Update target"):
        service.set_daily_target(target)
        st.success(f"Daily target set to {target} ml.")
    left, right = st.columns(2)
    with left:
        st.subheader("Daily intake trend")
        st.line_chart(s["daily_totals"])
    with right:
        st.subheader("Intake by beverage")
        st.bar_chart(s["beverage_totals"])
    st.subheader("Daily target comparison")
    st.dataframe([{"date": day, "intake_ml": value, "target_ml": s["daily_target_ml"],
                   "status": "Target met" if value >= s["daily_target_ml"] else "Below target"}
                  for day, value in s["daily_totals"].items()], use_container_width=True, hide_index=True)
elif page == "Intake register":
    keyword = st.text_input("Search entry ID or notes")
    beverage = st.text_input("Beverage filter")
    st.dataframe([r.to_dict() for r in service.search_entries(keyword, beverage)],
                 use_container_width=True, hide_index=True)
elif page == "Record intake":
    with st.form("intake_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        entry_id = c1.text_input("Entry ID")
        entry_date = c2.date_input("Date")
        entry_time = c1.time_input("Time")
        amount = c2.number_input("Amount (ml)", min_value=1, max_value=5000, value=250, step=50)
        beverage = c1.selectbox("Beverage", ["Water", "Warm water", "Sparkling water", "Other"])
        notes = c2.text_input("Notes (optional)")
        submitted = st.form_submit_button("Save intake")
    if submitted:
        try:
            r = service.add_entry(entry_id=entry_id, entry_date=entry_date.isoformat(),
                entry_time=entry_time.strftime("%H:%M"), amount_ml=amount,
                beverage=beverage, notes=notes)
            st.success(f"Recorded {r.amount_ml} ml on {r.entry_date}.")
        except ValueError as exc:
            st.error(str(exc))
elif page == "Import CSV":
    uploaded = st.file_uploader("Upload intake CSV", type=["csv"])
    if uploaded and st.button("Import rows"):
        temp = Path("data") / "_streamlit_import.csv"
        temp.write_bytes(uploaded.getvalue())
        try:
            result = import_csv(temp, service)
            st.success(f"Imported {result['imported']}; rejected {len(result['errors'])}.")
            if result["errors"]:
                st.dataframe([{"error": e} for e in result["errors"]], use_container_width=True)
        except ValueError as exc:
            st.error(str(exc))
        finally:
            temp.unlink(missing_ok=True)
elif page == "Exports":
    if st.button("Generate Markdown, CSV and chart"):
        md = export_markdown(service, "reports/water_summary.md")
        csv_file = export_csv(service, "reports/water_summary.csv")
        chart = export_chart(service, "reports/water_intake_trend.png")
        st.download_button("Download Markdown", md.read_bytes(), file_name=md.name)
        st.download_button("Download CSV", csv_file.read_bytes(), file_name=csv_file.name)
        st.image(str(chart), caption="Daily water intake trend")
